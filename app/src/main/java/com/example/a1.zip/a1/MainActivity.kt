package com.example.a1
import android.webkit.CookieManager
import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.util.Patterns
import android.view.Surface
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.net.InetAddress
import java.net.URI
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import com.example.a1.DynamicAnalysis
class MainActivity : AppCompatActivity() {

    private lateinit var dynamic: DynamicAnalysis // 동적 분석
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var barcodeScanner: BarcodeScanner
    private lateinit var previewView: PreviewView
    private lateinit var resultTextView: TextView
    private lateinit var webView: WebView  // 사용자용 WebView
    private lateinit var analysisWebView: WebView  // 분석용 WebView
    private lateinit var dynamicWebView: WebView //분석용 동적 WebView
    private lateinit var captureButton: FloatingActionButton
    private lateinit var openGalleryButton: ImageButton
    private lateinit var cameraControls: View
    private lateinit var cameraHintText: TextView
    private lateinit var urlSuggestionCard: View
    private lateinit var urlPreviewText: TextView
    private lateinit var openUrlButton: Button
    private lateinit var dismissUrlButton: ImageButton
    private lateinit var sandboxInfoPanel: View
    private lateinit var exitSandboxButton: Button
    private lateinit var webFeatureExtractor: WebFeatureExtractor
    private lateinit var analysisExecutor: ExecutorService

    private var requestedUrl: String? = null  // QR/사용자가 요청한 원본 URL (변경 금지)
    private var currentUrl: String? = null  // 실제로 로드된 URL (WebView 리다이렉트/에러 포함)
    private var isUserWebViewLoaded = false  // 사용자 WebView 로드 상태
    private var dynamicTotalRedirects: Int = 0
    private var dynamicExternalRedirects: Int = 0
    private var dynamicTotalErrors: Int = 0
    private var dynamicExternalErrors: Int = 0
    private var lastNavigationUrlForDynamicCounters: String? = null
    private var pendingDetectedUrl: String? = null
    private var lastDisplayedUrl: String? = null
    private var imageCapture: ImageCapture? = null
    private var isWebViewVisible = false
    private var lastAnalyzedPageKey: String? = null
    private var isAnalyzingFeatures = false
    private var lastWarningShownForUrl: String? = null
    private lateinit var phishingDetector: PhishingDetector
    private var lastCrpLogKey: String? = null
    private var autoSubmitArmed: Boolean = false
    private val requiredPermissions: Array<String> by lazy {
        val list = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            list.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        list.toTypedArray()
    }

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = requiredPermissions.all { perm ->
            permissions[perm] == true || ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED
        }
        if (allGranted) {
            startCamera()
        } else {
            Toast.makeText(this, "카메라 권한과 저장소 권한이 필요합니다", Toast.LENGTH_SHORT).show()
        }
    }




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        resultTextView = findViewById(R.id.resultTextView)
        webView = findViewById(R.id.webView)
        analysisWebView = findViewById(R.id.analysisWebView)
        captureButton = findViewById(R.id.captureButton)
        openGalleryButton = findViewById(R.id.openGalleryButton)
        cameraControls = findViewById(R.id.cameraControls)
        cameraHintText = findViewById(R.id.cameraHintText)
        urlSuggestionCard = findViewById(R.id.urlSuggestionCard)
        urlPreviewText = findViewById(R.id.urlPreviewText)
        openUrlButton = findViewById(R.id.openUrlButton)
        dismissUrlButton = findViewById(R.id.dismissUrlButton)
        sandboxInfoPanel = findViewById(R.id.sandboxInfoPanel)
        exitSandboxButton = findViewById(R.id.exitSandboxButton)
        dynamicWebView = findViewById(R.id.dynamicWebView)

        setupWebView()

        phishingDetector = PhishingDetector(this)
        analysisExecutor = Executors.newSingleThreadExecutor()

        captureButton.setOnClickListener { takePhoto() }
        openGalleryButton.setOnClickListener { openDefaultGallery() }
        openUrlButton.setOnClickListener { pendingDetectedUrl?.let { url -> launchSandbox(url) } }
        dismissUrlButton.setOnClickListener { clearPendingUrl() }
        exitSandboxButton.setOnClickListener { returnToCameraView() }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val options = BarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
            .build()
        barcodeScanner = BarcodeScanning.getClient(options)

        cameraExecutor = Executors.newSingleThreadExecutor()

        if (allPermissionsGranted()) {
            startCamera()
        } else {
            requestPermissionLauncher.launch(requiredPermissions)
        }

        val callback = object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    isWebViewVisible -> returnToCameraView()
                    urlSuggestionCard.visibility == View.VISIBLE -> clearPendingUrl()
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        }

        onBackPressedDispatcher.addCallback(this, callback)

        // Call after other setup, ensuring views are ready
        maybeLaunchDebugUrl()
    }

    private fun setupWebView() {
        setupUserWebView()
        setupAnalysisWebView()
        setupDynamicWebView()
    }

    private fun setupUserWebView() {
        with(webView.settings) {
            javaScriptEnabled = true  // 사용자용: JavaScript 활성화
            domStorageEnabled = true  // DOM Storage 활성화
            @Suppress("DEPRECATION")
            databaseEnabled = false
            cacheMode = WebSettings.LOAD_DEFAULT  // 사용자용: 캐시 사용
            setGeolocationEnabled(false)
            allowFileAccess = false
            allowContentAccess = false
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = false
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = false
            setSupportMultipleWindows(false)
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            safeBrowsingEnabled = true
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {

                super.onPageStarted(view, url, favicon)
                // 사용자 WebView의 페이지 로드 시작
                logIsolationCheck("USER_WEBVIEW_START", url, "사용자 WebView 페이지 로드 시작")
                Log.d(TAG, "User WebView - onPageStarted: $url")
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (!url.isNullOrBlank()) {
                    currentUrl = url
                    isUserWebViewLoaded = true
                    logIsolationCheck("USER_WEBVIEW_FINISH", url, "사용자 WebView 페이지 로드 완료")
                    Log.d(TAG, "User WebView - onPageFinished: $url")
                }
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                if (url != null && isValidUrl(url)) {
                    return false
                }
                Toast.makeText(this@MainActivity, "가상환경에서 허용되지 않는 URL입니다", Toast.LENGTH_SHORT).show()
                return true
            }
        }
    }

    private fun setupAnalysisWebView() {
        webFeatureExtractor = WebFeatureExtractor { features ->
            runOnUiThread {
                analyzeAndDisplayPhishingResult(features)
            }
        }

        // ========================================
        // 정적 분석 WebView 설정
        // ========================================
        // 용도: HTML 파싱 + 피처 추출만 (Javascript 제약)
        // 격리: Cookie 완전 차단 + DOM Storage 비활성화
        // 목표: 순수한 HTML 분석, 외부 영향 없음
        with(analysisWebView.settings) {
            javaScriptEnabled = true  // 피처 추출을 위해 필요
            domStorageEnabled = false  // ✅ DOM Storage 비활성화 (순수 분석)
            @Suppress("DEPRECATION")
            databaseEnabled = false
            cacheMode = WebSettings.LOAD_NO_CACHE  // 캐시 미사용
            setGeolocationEnabled(false)
            allowFileAccess = false
            allowContentAccess = false
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = false
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = false
            setSupportMultipleWindows(false)
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            safeBrowsingEnabled = true
        }

        // ✅ 정적 분석 WebView의 쿠키 완전 차단
        CookieManager.getInstance().apply {
            removeAllCookies(null)  // 기존 쿠키 삭제
            setAcceptCookie(false)  // 새 쿠키 거부
        }

        WebView.setWebContentsDebuggingEnabled(true)

        analysisWebView.addJavascriptInterface(webFeatureExtractor, "Android")

        analysisWebView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                resultTextView.text = "🔍 웹페이지 분석 중..."

                // 격리 확인 로그: Analysis WebView 페이지 시작
                logIsolationCheck("ANALYSIS_WEBVIEW_START", url, "분석용 WebView 페이지 로드 시작 (사용자 미표시)")

                if (!url.isNullOrBlank()) {
                    val prev = lastNavigationUrlForDynamicCounters
                    if (prev != null && prev != url) {
                        dynamicTotalRedirects++
                        val prevHost = runCatching { URI(prev).host }.getOrNull()?.lowercase(Locale.ROOT)
                        val curHost = runCatching { URI(url).host }.getOrNull()?.lowercase(Locale.ROOT)
                        if (!prevHost.isNullOrBlank() && !curHost.isNullOrBlank() && prevHost != curHost) {
                            dynamicExternalRedirects++
                        }
                    }
                    lastNavigationUrlForDynamicCounters = url
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (!url.isNullOrBlank()) {
                    currentUrl = url
                    if (shouldAnalyzeUrl(url)) {
                        resultTextView.text = "🔍 가상환경에서 피처 분석 중..."
                        logIsolationCheck("ANALYSIS_WEBVIEW_FINISH", url, "분석용 WebView 페이지 로드 완료, 피처 추출 시작")
                        extractWebFeatures()
                    }
                }
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                if (url != null && isValidUrl(url)) {
                    return false
                }
                Toast.makeText(this@MainActivity, "가상환경에서 허용되지 않는 URL입니다", Toast.LENGTH_SHORT).show()
                return true
            }
        }
    }

    // ========================================
    // 동적 분석 WebView 캐싱 및 초기화
    // ========================================
    // assets/dynamic_bot.js 를 "한 번만" 읽어서 캐싱 (페이지 이동마다 IO 방지)
    private val dynamicBotJs: String by lazy {
        assets.open("dynamic_bot.js")
            .bufferedReader()
            .use { it.readText() }
    }

    private fun setupDynamicWebView() {
        // ========================================
        // 동적 분석 WebView 설정
        // ========================================
        // 용도: JavaScript 봇 실행 + 자동 폼 제출 + 리다이렉트 감지
        // 격리: Cookie/DOM Storage 활성 + 매번 완전 정리(wipe)
        // 목표: 봇이 자유롭게 DOM 조작, 매번 깨끗한 상태 시작

        // ✅ UI 격리(실수 방지)
        // - 사용자 화면에 절대 보이면 안 되니까 처음부터 숨김
        // - 포커스도 못 받게 해서 클릭/키보드 이벤트가 안 가게 함
        dynamicWebView.visibility = View.GONE
        dynamicWebView.isFocusable = false
        dynamicWebView.isFocusableInTouchMode = false

        // ✅ WebView 디버깅은 Debug 빌드에서만 켜기(릴리즈 빌드 보안/성능)
        if (BuildConfig.DEBUG) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        // ✅ 쿠키 정책 (봇이 필요하므로 활성화)
        // - acceptCookie: true (봇이 폼 제출할 때 쿠키 필요)
        // - 대신 dynamic.start()에서 매번 removeAllCookies() + deleteAllData()로 정리
        // - 3rd-party cookie: false (추적 쿠키 제한)
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)  // 봇이 필요
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cm.setAcceptThirdPartyCookies(dynamicWebView, false)  // 추적 차단
        }

        // ✅ 모듈 생성: Activity는 결과 콜백만 제공
        // - setup()/start()/stop()은 DynamicAnalysis가 담당
        dynamic = DynamicAnalysis(
            activity = this,
            webView = dynamicWebView,
            botScript = dynamicBotJs,
            onStatus = { text ->
                runOnUiThread { resultTextView.text = text }
            }
        )

        // DynamicAnalysis가 WebView 설정/브릿지/클라이언트/JS 주입 처리
        // (DynamicAnalysis.setup()에서 domStorageEnabled=true로 설정함)
        dynamic.setup()
    }




        private fun startDynamicSession(targetUrl: String) {
        // 1) 이전 세션 정리
        dynamicWebView.apply {
            stopLoading()
            clearHistory()
            clearCache(true)
            loadUrl("about:blank")
        }

        // 2) 쿠키/스토리지 삭제 – 샌드박스 느낌
        val cookieManager = android.webkit.CookieManager.getInstance()
        cookieManager.removeAllCookies(null)
        cookieManager.flush()
        android.webkit.WebStorage.getInstance().deleteAllData()

        Log.d("DynamicTest", "🚀 Dynamic-only sandbox start: $targetUrl")

        // 3) URL 로드
        dynamicWebView.post {
            dynamicWebView.loadUrl(targetUrl)
        }
    }


    private fun launchSandbox(url: String) {
        pendingDetectedUrl = null
        isWebViewVisible = true
        requestedUrl = url  // ✅ 원본 URL 저장 (이후 변경 금지)
        currentUrl = url    // 초기값은 동일하지만, WebView 리다이렉트/에러 시 업데이트됨
        lastAnalyzedPageKey = null
        isAnalyzingFeatures = false
        isUserWebViewLoaded = false
        urlSuggestionCard.visibility = View.GONE
        cameraControls.visibility = View.GONE
        cameraHintText.visibility = View.GONE
        previewView.visibility = View.GONE
        sandboxInfoPanel.visibility = View.VISIBLE

        // (원래는 analysisWebView 기준이었지만 그냥 놔둬도 됨)
        dynamicTotalRedirects = 0
        dynamicExternalRedirects = 0
        lastNavigationUrlForDynamicCounters = null

        // 격리 확인 로그 – 메시지도 동적 기준으로 바꿔주면 보기 좋음
        logIsolationCheck("SANDBOX_START", url, "Static webview애서 정적 분석 시작")

        // 화면 텍스트도 정적 → 동적으로 변경
        resultTextView.text = "🧪 샌드박스에서 분석 중...\n$url"

        analysisWebView.loadUrl(url)


//        // 1) 동적 WebView 세션 깨끗하게 초기화
//
//        dynamicWebView.apply {
//
//            clearHistory()
//            clearCache(true)
//            stopLoading()
//            loadUrl("about:blank")
//        }
//        // 2) 쿠키/스토리지 날려서 샌드박스 느낌 내기
//        val cookieManager = CookieManager.getInstance()
//        cookieManager.removeAllCookies(null)
//        cookieManager.flush()
//        WebStorage.getInstance().deleteAllData()
//
//        // 3) 실제 URL을 동적 WebView에 로드
//        dynamic.start(url, bootstrapMs = 3500L);
//        """
//        dynamicWebView.post {
//            Log.d(TAG, "Dynamic sandbox load: $url") // 이부분 강제 다이나믹 실행
//            dynamicWebView.loadUrl(url)
//        }
//        """
    }


    private fun returnToCameraView() {
        if (!isWebViewVisible) return
        isWebViewVisible = false

        logIsolationCheck("CLEANUP_START", null, "샌드박스 정리 시작")

        // 사용자 WebView 정리
        webView.stopLoading()
        webView.loadUrl("about:blank")
        webView.clearCache(true)
        webView.visibility = View.GONE
        logIsolationCheck("USER_WEBVIEW_CLEANED", null, "사용자 WebView 정리 완료")

        // 분석 WebView 정리
        analysisWebView.stopLoading()
        analysisWebView.loadUrl("about:blank")
        analysisWebView.clearCache(true)
        logIsolationCheck("ANALYSIS_WEBVIEW_CLEANED", null, "분석 WebView 정리 완료")

        previewView.visibility = View.VISIBLE
        sandboxInfoPanel.visibility = View.GONE
        cameraControls.visibility = View.VISIBLE
        cameraHintText.visibility = View.VISIBLE
        clearPendingUrl(true)
        lastAnalyzedPageKey = null
        isAnalyzingFeatures = false
        isUserWebViewLoaded = false
        requestedUrl = null  // ✅ 원본 URL 정리
        currentUrl = null
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            try {
                val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()
                val preview = Preview.Builder()
                    .setTargetRotation(previewView.display?.rotation ?: Surface.ROTATION_0)
                    .build()
                    .also { it.setSurfaceProvider(previewView.surfaceProvider) }

                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .setTargetRotation(previewView.display?.rotation ?: Surface.ROTATION_0)
                    .build()

                val imageAnalyzer = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    .also { it.setAnalyzer(cameraExecutor, BarcodeAnalyzer()) }

                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, imageCapture, imageAnalyzer
                )

            } catch (exc: Exception) {
                Log.e(TAG, "카메라 시작 실패", exc)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private inner class BarcodeAnalyzer : ImageAnalysis.Analyzer {
        @androidx.camera.core.ExperimentalGetImage
        override fun analyze(imageProxy: ImageProxy) {
            if (pendingDetectedUrl != null || isWebViewVisible) {
                imageProxy.close()
                return
            }
            val mediaImage = imageProxy.image
            if (mediaImage != null) {
                val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                barcodeScanner.process(image)
                    .addOnSuccessListener { barcodes ->
                        if (pendingDetectedUrl != null || isWebViewVisible) return@addOnSuccessListener
                        for (barcode in barcodes) {
                            val rawValue = barcode.rawValue
                            if (rawValue != null && isValidUrl(rawValue)) {
                                if (rawValue != lastDisplayedUrl) {
                                    runOnUiThread {
                                        currentUrl = rawValue
                                        showUrlSuggestion(rawValue)
                                    }
                                }
                            } else if (!rawValue.isNullOrBlank()) {
                                runOnUiThread {
                                    cameraHintText.text = "📄 QR 코드 내용: $rawValue"
                                }
                            }
                        }
                    }
                    .addOnFailureListener { Log.e(TAG, "바코드 스캔 실패", it) }
                    .addOnCompleteListener { imageProxy.close() }
            } else {
                imageProxy.close()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        analysisExecutor.shutdown()
        cameraExecutor.shutdown()
        barcodeScanner.close()
    }

    private fun takePhoto() {
        val capture = imageCapture
        if (capture == null) {
            Toast.makeText(this, "카메라 초기화 중입니다", Toast.LENGTH_SHORT).show()
            return
        }

        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "QR_$name")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/YUQR")
            }
        }
        val outputOptions = ImageCapture.OutputFileOptions
            .Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
            .build()

        capture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    cameraHintText.text = "사진이 갤러리에 저장되었습니다"
                    Toast.makeText(this@MainActivity, "갤러리에 저장 완료", Toast.LENGTH_SHORT).show()
                }

                override fun onError(exception: ImageCaptureException) {
                    Log.e(TAG, "사진 저장 실패", exception)
                    Toast.makeText(this@MainActivity, "사진 저장 실패: ${exception.message}", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    private fun openDefaultGallery() {
        val intent = Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        runCatching {
            startActivity(intent)
        }.onFailure {
            Toast.makeText(this, "갤러리를 열 수 없습니다", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showUrlSuggestion(url: String) {
        pendingDetectedUrl = url
        lastDisplayedUrl = url
        urlPreviewText.text = formatUrlPreview(url)
        urlSuggestionCard.visibility = View.VISIBLE
        cameraHintText.text = "감지된 URL을 분석하려면 \'가상분석\'을 누르세요"
    }

    private fun clearPendingUrl(allowSameUrlAgain: Boolean = false) {
        pendingDetectedUrl = null
        urlSuggestionCard.visibility = View.GONE
        if (allowSameUrlAgain) {
            lastDisplayedUrl = null
        }
        if (!isWebViewVisible) {
            cameraHintText.text = DEFAULT_CAMERA_HINT
        }
    }

    private fun formatUrlPreview(url: String): String {
        return if (url.length <= 60) url else "${url.take(57)}..."
    }

    private fun allPermissionsGranted(): Boolean {
        return requiredPermissions.all { perm ->
            ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun extractWebFeatures() {
        Log.d(TAG, "extractWebFeatures() 호출됨 - 요청URL: $requestedUrl, 실제URL: $currentUrl")
        isAnalyzingFeatures = true

        // ✅ 원본 URL을 JavaScript로 전달 (WebView 리다이렉트/에러 영향 없음)
        val script = webFeatureExtractor.getFeatureExtractionScript(requestedUrl ?: currentUrl ?: "")
        Log.d(TAG, "JS 스크립트 실행 요청 - URL: ${requestedUrl ?: currentUrl}")
        analysisWebView.evaluateJavascript(script) { result ->
            Log.d(TAG, "evaluateJavascript 완료, result=$result")
        }
    }

    private fun analyzeAndDisplayPhishingResult(features: WebFeatures) {
        Log.d(TAG, "analyzeAndDisplayPhishingResult() 호출됨, 피처 수: ${features.size}")
        // ✅ 분석용 URL은 원본 URL (requestedUrl) 사용
        val urlForAnalysis = requestedUrl ?: currentUrl

        analysisExecutor.execute {
            try {
                val merged = features.toMutableMap()


                if ((merged["nb_redirection"] ?: 0f) > 0f) {
                    val totalRedirects = (merged["nb_redirection"] ?: 0f).toInt()
                    val externalRedirects = (merged["nb_external_redirection"] ?: 0f).toInt()
                    val internalRedirects = totalRedirects - externalRedirects

                    merged["ratio_intRedirection"] = if (totalRedirects > 0) internalRedirects.toFloat() / totalRedirects else 0f
                    merged["ratio_extRedirection"] = if (totalRedirects > 0) externalRedirects.toFloat() / totalRedirects else 0f
                } else {
                    merged["ratio_intRedirection"] = 0f
                    merged["ratio_extRedirection"] = 0f
                }

                // ✅ statistical_report는 WebFeatureExtractor에서 이미 계산됨 (외부 조회 없음)
                // ✅ 따라서 여기서 덮어씌우지 않음 - 패턴 매칭 기반 값 유지
                if (!merged.containsKey("statistical_report")) {
                    merged["statistical_report"] = 0f  // 예외: 계산되지 않은 경우만 기본값
                }

                Log.d(TAG, "static features - nb_redirection=${merged["nb_redirection"]}, nb_external_redirection=${merged["nb_external_redirection"]}, statistical_report=${merged["statistical_report"]}")

                val analysisResult = phishingDetector.analyzePhishing(merged, urlForAnalysis)
                runOnUiThread {
                    isAnalyzingFeatures = false
                    lastAnalyzedPageKey = analysisResult.inspectedUrl ?: urlForAnalysis

                    if (analysisResult.isPhishing) {
                        // 피싱 판정: 경고 후 분석 WebView 폐기
                        logIsolationCheck("PHISHING_DETECTED", urlForAnalysis, "Analysis WebView 정리, User WebView 로드 안 함")
                        analysisWebView.loadUrl("about:blank")
                        renderAnalysis(analysisResult)
                    } else {
                        // 안전 판정: 사용자 WebView에 로드
                        logIsolationCheck("SAFE_VERDICT", urlForAnalysis, "User WebView 표시 및 로드 시작")

                        //안전일경우 동적분석 시작
                        val targetUrl = urlForAnalysis ?: ""
                        // 1. 정적 웹뷰 폐기 (시키는 대로 바로 날림)
                        logIsolationCheck("STATIC_CLEANUP", targetUrl, "정적 분석 완료 -> Analysis WebView 초기화")
                        analysisWebView.loadUrl("about:blank")

                        // 2. 동적 분석 실행 (시간 설정 X, 결과 오면 실행할 내용만 전달)
                        logIsolationCheck("DYNAMIC_START", targetUrl, "동적 분석 시작")
                        resultTextView.text = "🧪 정적 통과. 동적 분석 중..."

                        dynamic.start(targetUrl) { isSafe ->
                            runOnUiThread {
                                if (isSafe) {
                                    // [안전] -> 사용자 화면 켜기
                                    logIsolationCheck("DYNAMIC_SAFE", targetUrl, "안전 -> 사용자 뷰 오픈")

                                    webView.visibility = View.VISIBLE
                                    webView.loadUrl(targetUrl)

                                    resultTextView.text = "✅ 분석 완료. 안전함."
                                    renderAnalysis(analysisResult, allowModal = false)
                                } else {
                                    // [위험] -> 차단
                                    logIsolationCheck("DYNAMIC_FAIL", targetUrl, "위험 -> 차단")
                                    Toast.makeText(
                                        this@MainActivity,
                                        "차단되었습니다.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    dynamicWebView.loadUrl("about:blank")
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to analyze phishing features", e)
                runOnUiThread {
                    isAnalyzingFeatures = false
                    Toast.makeText(this, "분석 중 오류가 발생했습니다", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }




    private fun renderAnalysis(analysisResult: PhishingAnalysisResult, allowModal: Boolean = true) {
        val modeDescription = "ML 기반 통합 분석"
        val targetUrl = analysisResult.inspectedUrl ?: currentUrl

        val resultText = StringBuilder().apply {
            append("ML 기반 피싱 분석 결과\n")
            append("━━━━━━━━━━━━━━━━━━━━\n")
            append("피싱 확률: ${(analysisResult.confidenceScore.coerceIn(0.0, 1.0) * 100).toInt()}%\n")
            append("판정 결과: ${if (analysisResult.isPhishing) "🚨 피싱 의심" else "✅ 안전"}\n")
            append("분석 모드: $modeDescription\n")
            targetUrl?.let {
                append("분석 URL: $it\n")
            }

            val features = analysisResult.features
            if (features != null) {
                append("\n📋 WebView 피처 분석:\n")
                // match the actual feature names produced by the JS extractor / feature_info.json
                append("• URL 길이: ${features["length_url"]?.toInt() ?: 0}\n")
                append("• iframe (invisible?) flag: ${features["iframe"]?.toInt() ?: 0}\n")
                append("• 로그인/외부 폼 (login_form): ${if (features["login_form"] == 1.0f) "있음" else "없음"}\n")
                append("• 외부 CSS 파일 수 (nb_extCSS): ${features["nb_extCSS"]?.toInt() ?: 0}\n")
                append("• 총 리다이렉션 (nb_redirection): ${features["nb_redirection"]?.toInt() ?: 0} / 외부 리다이렉션: ${features["nb_external_redirection"]?.toInt() ?: 0}\n")
                append("• 의심 키워드 수 (phish_hints): ${features["phish_hints"]?.toInt() ?: 0}\n")
                append("• 의심 TLD (suspecious_tld): ${if (features["suspecious_tld"] == 1.0f) "예" else "아니오"}\n")
                append("• 브랜드 포함(domain_in_brand / brand_in_path): ${if (features["domain_in_brand"] == 1.0f) "도메인에 브랜드 있음" else if (features["brand_in_path"] == 1.0f) "경로에 브랜드 있음" else "아님"}\n")
            }

            if (analysisResult.riskFactors.isNotEmpty()) {
                append("\nML 분석 결과:\n")
                analysisResult.riskFactors.distinct().forEach { factor ->
                    append("• $factor\n")
                }
            }

            append("\n시스템 특징:\n")
            append("• 온-디바이스 ML 모델 사용\n")
            append("• 외부 서버 통신 없음\n")
            append("• WebView 기반 행위 분석\n")
            append("• 실시간 프라이버시 보호\n")

            append("\n권장사항:\n")
            if (analysisResult.isPhishing) {
                append("• 이 사이트를 신뢰하지 마세요\n")
                append("• 개인정보를 입력하지 마세요\n")
                append("• 즉시 페이지를 닫으세요")
            } else {
                append("• 안전한 사이트로 보입니다\n")
                append("• 그래도 주의해서 사용하세요")
            }
        }

        resultTextView.text = resultText.toString()

        if (allowModal) {
            val warningKey = targetUrl ?: NO_URL_WARNING_KEY
            if (analysisResult.isPhishing) {
                webView.stopLoading()
                webView.loadUrl("about:blank")
                if (lastWarningShownForUrl != warningKey) {
                    lastWarningShownForUrl = warningKey
                    showPhishingWarningDialog(analysisResult)
                }
            } else if (lastWarningShownForUrl == warningKey) {
                lastWarningShownForUrl = null
            }
        }
    }

    private fun showPhishingWarningDialog(analysisResult: PhishingAnalysisResult) {
        val messageBuilder = StringBuilder().apply {
            append("ML 모델이 이 웹페이지를 피싱으로 분석했습니다!\n\n")
            append("피싱 확률: ${(analysisResult.confidenceScore.coerceIn(0.0, 1.0) * 100).toInt()}%\n\n")
            append("분석 방식:\n")
            append("• 온-디바이스 머신러닝 모델\n")
            append("• WebView 기반 행위 분석\n")
            append("• 실시간 피처 추출 및 판정\n\n")
            if (analysisResult.riskFactors.isNotEmpty()) {
                append("ML 분석 근거:\n")
                analysisResult.riskFactors.distinct().forEach { factor ->
                    append("• $factor\n")
                }
                append("\n")
            }
            append("보안 권장사항:\n")
            append("• 이 사이트에서 어떠한 정보도 입력하지 마세요\n")
            append("• 개인정보, 비밀번호, 신용카드 정보를 절대 입력하지 마세요\n")
            append("• 의심스러운 링크는 클릭하지 마세요\n")
            append("• 즉시 이 페이지를 닫으세요\n\n")
            append("연결은 차단됐으며 카메라 화면으로 돌아갑니다.")
        }

        AlertDialog.Builder(this)
            .setTitle("ML 기반 피싱 경고!")
            .setMessage(messageBuilder.toString())
            .setPositiveButton("확인") { _, _ -> returnToCameraView() }
            .setCancelable(false)
            .show()
    }

    private fun isValidUrl(url: String): Boolean {
        return Patterns.WEB_URL.matcher(url).matches() || url.startsWith("http://") || url.startsWith("https://")
    }

    private fun shouldAnalyzeUrl(url: String): Boolean {
        if (url.isBlank() || url.equals("about:blank", ignoreCase = true)) return false
        if (isAnalyzingFeatures) return false
        if (lastAnalyzedPageKey != null && lastAnalyzedPageKey == url) return false
        return true
    }


    /**
     * 두 WebView의 격리 상태를 로깅하는 함수
     * 분석용 WebView와 사용자 WebView가 완벽히 격리되어 있는지 확인
     */
    private fun logIsolationCheck(event: String, url: String?, description: String) {
        val timestamp = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())
        val userWebViewVisible = webView.visibility == View.VISIBLE
        val analysisWebViewVisible = analysisWebView.visibility == View.VISIBLE
        val userWebViewLoaded = isUserWebViewLoaded
        val isAnalyzing = isAnalyzingFeatures

        val isolationStatus = StringBuilder().apply {
            append("\n")
            append("╔════════════════════════════════════════════════════════╗\n")
            append("║ 🔒 WebView 격리 상태 확인                              ║\n")
            append("╠════════════════════════════════════════════════════════╣\n")
            append("║ ⏰ 시간: $timestamp\n")
            append("║ 📌 이벤트: $event\n")
            append("║ 📝 설명: $description\n")
            append("║ 🌐 URL: ${url ?: "N/A"}\n")
            append("╠════════════════════════════════════════════════════════╣\n")
            append("║ [분석용 WebView - analysisWebView]\n")
            append("║  ├─ 표시여부: ${if (analysisWebViewVisible) "✅ 보임 (ERROR!)" else "❌ 숨김 (정상)"}\n")
            append("║  ├─ 용도: 특징값 추출 (사용자에게 미표시)\n")
            append("║  ├─ JavaScript: 활성화\n")
            append("║  └─ 캐시: LOAD_NO_CACHE\n")
            append("║\n")
            append("║ [사용자 WebView - webView]\n")
            append("║  ├─ 표시여부: ${if (userWebViewVisible) "✅ 보임 (정상)" else "❌ 숨김"}\n")
            append("║  ├─ 로드상태: ${if (userWebViewLoaded) "✅ 로드됨" else "❌ 로드전"}\n")
            append("║  ├─ 용도: 최종 사용자 표시\n")
            append("║  ├─ JavaScript: 활성화\n")
            append("║  └─ 캐시: LOAD_DEFAULT\n")
            append("║\n")
            append("║ [분석 상태]\n")
            append("║  ├─ 현재 분석중: ${if (isAnalyzing) "🔄 진행중" else "✅ 대기중"}\n")
            append("║  └─ 현재 URL: ${currentUrl ?: "N/A"}\n")
            append("║\n")
            append("║ [격리 검증]\n")

            // 격리 상태 검증
            val isolationValid = !analysisWebViewVisible &&
                                 (userWebViewVisible || !isWebViewVisible)

            if (isolationValid) {
                append("║  ✅ 두 WebView가 완벽히 격리됨!\n")
            } else {
                append("║  ⚠️  격리 상태 비정상!\n")
                if (analysisWebViewVisible) {
                    append("║     └─ ERROR: 분석 WebView가 보임\n")
                }
            }

            append("╚════════════════════════════════════════════════════════╝\n")
        }

        Log.d(TAG, isolationStatus.toString())

        // Logcat에서 쉽게 찾을 수 있도록 분리된 로그도 추가
        Log.i("ISOLATION_CHECK", "$event | UserWebView: ${if (userWebViewVisible) "VISIBLE" else "GONE"} | AnalysisWebView: ${if (analysisWebViewVisible) "VISIBLE" else "GONE"} | Analyzing: ${if (isAnalyzing) "YES" else "NO"}")
    }

    companion object {
        private const val TAG = "MainActivity"
        private const val NO_URL_WARNING_KEY = "__NO_URL__"
        private const val DEFAULT_CAMERA_HINT = "QR을 비추면 위협 URL이 여기에 나타납니다"
        private const val DEBUG_AUTO_LAUNCH_URL = "https://watch.formed.org/login" // 여기 url 하드코딩
    }

    private fun maybeLaunchDebugUrl() {
        // UI가 완전히 준비된 후 실행하기 위해 1초(1000ms) 지연 실행
        findViewById<View>(android.R.id.content).postDelayed({
            if (DEBUG_AUTO_LAUNCH_URL.isNotBlank()) {
                cameraHintText.text = "디버그 URL 자동 분석 중..."
                launchSandbox(DEBUG_AUTO_LAUNCH_URL)
            }
        }, 1000)
    }





    }
